## Chatterbox-Multilingual
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/NeuralFalconYT/Chatterbox-Multilingual/blob/main/Chatterbox_Multilingual.ipynb) <br>

![aa](https://github.com/user-attachments/assets/2b82bd12-9dad-4ed8-8c89-f244d264803a)


## Credit:
[Chatbox](https://github.com/chatboxai/chatbox)
